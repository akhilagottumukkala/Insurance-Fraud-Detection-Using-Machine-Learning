import streamlit as st
import pandas as pd
import pickle
import numpy as np

# --- Configuration & Styling ---
st.set_page_config(page_title="Insurance Fraud Detector", page_icon="🛡️")

# CSS to make the app look modern
st.markdown("""
    <style>
    .main { background-color: #f5f7f9; }
    .stButton>button { width: 100%; border-radius: 5px; height: 3em; background-color: #007bff; color: white; }
    </style>
    """, unsafe_allow_html=True)

# --- Load Model and Columns ---
@st.cache_resource # Keeps the model in memory for faster loading
def load_assets():
    with open('fraud_model.pkl', 'rb') as f:
        model = pickle.load(f)
    with open('model_columns.pkl', 'rb') as f:
        cols = pickle.load(f)
    return model, cols

try:
    model, model_columns = load_assets()
except FileNotFoundError:
    st.error("⚠️ Error: .pkl files not found! Run the training script first.")
    st.stop()

# --- App Header ---
st.title("🛡️ Insurance Fraud Detection System")
st.info("Input the claim details below to evaluate the fraud risk level.")

# --- Epic 7: User Input Interface ---
col1, col2 = st.columns(2)

with col1:
    st.subheader("Customer Details")
    age = st.slider("Customer Age", 18, 100, 35)
    months = st.number_input("Months as Customer", 0, 500, 120)
    policy_premium = st.number_input("Annual Premium ($)", 0.0, 5000.0, 1200.0)
    policy_deductible = st.selectbox("Policy Deductible", [500, 1000, 2000])

with col2:
    st.subheader("Incident Details")
    incident_severity = st.selectbox("Incident Severity", 
        ["Trivial Damage", "Minor Damage", "Major Damage", "Total Loss"])
    incident_type = st.selectbox("Incident Type", 
        ["Single Vehicle Collision", "Multi-vehicle Collision", "Parked Car", "Vehicle Theft"])
    total_claim = st.number_input("Total Claim Amount ($)", 0, 200000, 50000)
    witnesses = st.slider("Number of Witnesses", 0, 3, 1)

# --- Prediction Logic ---
if st.button("Analyze Claim for Fraud"):
    # 1. Prepare input data
    input_data = pd.DataFrame(columns=model_columns)
    input_data.loc[0] = 0 # Initialize all 140+ columns to 0
    
    # 2. Map Numerical Inputs
    input_data.at[0, 'age'] = age
    input_data.at[0, 'months_as_customer'] = months
    input_data.at[0, 'policy_annual_premium'] = policy_premium
    input_data.at[0, 'policy_deductable'] = policy_deductible
    input_data.at[0, 'total_claim_amount'] = total_claim
    input_data.at[0, 'witnesses'] = witnesses
    
    # 3. Map Categorical Inputs (Handling the One-Hot Encoded flags)
    # The code looks for column names like 'incident_severity_Major Damage'
    severity_col = f"incident_severity_{incident_severity}"
    type_col = f"incident_type_{incident_type}"
    
    if severity_col in model_columns: input_data.at[0, severity_col] = 1
    if type_col in model_columns: input_data.at[0, type_col] = 1

    # 4. Predict
    prediction = model.predict(input_data)[0]
    prob = model.predict_proba(input_data)[0][1]

    # --- Result Display ---
    st.divider()
    if prediction == 1:
        st.error(f"### 🚩 High Risk: Fraud Suspected!")
        st.write(f"The system is **{prob:.2%}** confident that this is a fraudulent claim.")
        st.warning("Recommendation: Refer to the Special Investigation Unit (SIU).")
    else:
        st.success(f"### ✅ Low Risk: Genuine Claim")
        st.write(f"The system is **{1-prob:.2%}** confident that this claim is legal.")
        st.info("Recommendation: Proceed with standard claim processing.")

st.sidebar.markdown("""
### **About the Project**
This AI model uses **Gradient Boosting** to detect patterns in vehicle damage, claim amounts, and customer history.
""")